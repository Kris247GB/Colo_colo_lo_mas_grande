package com.mycompany.proyecto;

import com.mycompany.proyecto.Vista.Vista;
public class Proyecto {

    public static void main(String[] args) {
        Vista principal = new Vista();
        principal.setVisible(true);
        principal.setLocationRelativeTo(null);
        
    }
}