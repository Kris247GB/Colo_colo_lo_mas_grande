package com.mycompany.proyecto.Modelo;

import com.mycompany.proyecto.Interfaz.ClienteDAO;
import java.util.ArrayList;

public class AdminCliente implements ClienteDAO {
    ArrayList<Cliente> listaClientes;
    public AdminCliente(){
        listaClientes = new ArrayList();
    }

    @Override
    public String crearCliente(String nombre, String rut, String email, String telefono) {
        if(rut.length()!=10||!email.contains("@") || nombre.length()<4){
            return "Debe ingresar los campos correctamente";
        }else{
            for(Cliente clienteGuardado : listaClientes) {
                if(clienteGuardado.getRut().equalsIgnoreCase(rut)){
                        return "El cliente ya existe";
                }
            }
            Cliente nuevoCliente = new Cliente(nombre, rut, email);
            nuevoCliente.setTelefono(telefono);
            listaClientes.add(nuevoCliente);
            return "Cliente creadoe exitosamente";
        }
    }

    @Override
    public boolean eliminarCliente(String rut) {
        for(Cliente clienteGuardado : listaClientes) {
            if(clienteGuardado.getRut().equalsIgnoreCase(rut)) {
                return listaClientes.remove(clienteGuardado);
            }
        }
        return false;
    }

    @Override
    public ArrayList<Cliente> obtenerClientes() {
        return listaClientes;
    }

    @Override
    public boolean editarCliente(String rut, String nombre, String email, String telefono) {
        for(Cliente clienteGuardado : listaClientes) {
            if(clienteGuardado.getRut().equalsIgnoreCase(rut)) {
                clienteGuardado.setNombre(nombre);
                clienteGuardado.setEmail(email);
                clienteGuardado.setTelefono(telefono);
                return true;
            }
        }
        return false;
    }

    @Override
    public Cliente buscarCliente(String rut) {
        for(Cliente clienteGuardado : listaClientes) {
            if(clienteGuardado.getRut().equalsIgnoreCase(rut)) {
                return clienteGuardado;
            }                
        }
        return null;
    }
}




