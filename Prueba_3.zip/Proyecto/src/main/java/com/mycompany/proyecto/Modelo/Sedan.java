package com.mycompany.proyecto.Modelo;

public class Sedan extends Vehiculo {
    private int capacidadMaletero;

    public Sedan() {
        capacidadMaletero = 0;
    }

    public Sedan(int capacidadMaletero) {
        this.capacidadMaletero = capacidadMaletero;
    }

    public Sedan(int capacidadMaletero, String codigo, String marca, String modelo, String patente, double precio) {
        super(codigo, marca, modelo, patente, precio);
        this.capacidadMaletero = capacidadMaletero;
    }

    public int getCapacidadMaletero() {
        return capacidadMaletero;
    }

    public void setCapacidadMaletero(int capacidadMaletero) {
        this.capacidadMaletero = capacidadMaletero;
    }
    

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Capacidad maletero: " + capacidadMaletero + " litros.");
    }
    
}
