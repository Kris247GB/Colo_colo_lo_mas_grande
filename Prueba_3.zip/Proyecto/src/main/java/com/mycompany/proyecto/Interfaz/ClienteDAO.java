package com.mycompany.proyecto.Interfaz;

import com.mycompany.proyecto.Modelo.Cliente;
import java.util.ArrayList;

public interface ClienteDAO {
    String crearCliente(String nombreCompleto, String rut, String email, String telefono);
    boolean eliminarCliente(String rut);
    ArrayList<Cliente> obtenerClientes();
    boolean editarCliente (String rut, String nombreCompleto, String email, String telefono);
    Cliente buscarCliente (String rut);
}
