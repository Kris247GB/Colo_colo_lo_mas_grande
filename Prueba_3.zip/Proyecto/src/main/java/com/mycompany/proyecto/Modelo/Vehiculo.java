package com.mycompany.proyecto.Modelo;

public abstract class Vehiculo {
    protected String codigo;
    protected String marca;
    protected String modelo;   
    protected String patente;   
    protected double precio;

    public Vehiculo() {
        codigo = "";
        marca = "";
        modelo = "";
        patente = "";
        precio = 0;
    }

    public Vehiculo(String codigo, String marca, String modelo, String patente, double precio) {
        this.codigo = codigo;
        this.marca = marca;
        this.modelo = modelo;
        this.patente = patente;
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void mostrarInformacion() {      
        System.out.println("Codigo: " + codigo);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Patente: " + patente);
        System.out.println("Precio: " + precio);
    }
}
