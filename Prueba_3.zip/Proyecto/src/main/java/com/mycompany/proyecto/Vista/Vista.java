package com.mycompany.proyecto.Vista;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Vista extends javax.swing.JFrame {
    
    public Vista() {
        initComponents();
    }

    public JButton getBtnAgregar() {
        return BtnAgregar;
    }

    public JButton getBtnContinuar() {
        return BtnContinuar;
    }

    public JButton getBtnLimpiar() {
        return BtnLimpiar;
    }

    public JButton getBtnSalir() {
        return BtnSalir;
    }

    public JTextField getTexto1() {
        return Texto1;
    }

    public JTextField getTexto2() {
        return Texto2;
    }

    public JTextField getTexto3() {
        return Texto3;
    }

    public JTextField getTexto4() {
        return Texto4;
    }

    public JLabel getjLabelIngresoCliente() {
        return jLabelIngresoCliente;
    }

    public JLabel getjLabelMail() {
        return jLabelMail;
    }

    public JLabel getjLabelNombre() {
        return jLabelNombre;
    }

    public JLabel getjLabelRut() {
        return jLabelRut;
    }

    public JLabel getjLabelTelefono() {
        return jLabelTelefono;
    }

    public JPanel getjPanel1() {
        return jPanel1;
    }
    
    
    @SuppressWarnings("unchecked")
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelIngresoCliente = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jLabelRut = new javax.swing.JLabel();
        jLabelMail = new javax.swing.JLabel();
        jLabelTelefono = new javax.swing.JLabel();
        Texto1 = new javax.swing.JTextField();
        Texto3 = new javax.swing.JTextField();
        Texto2 = new javax.swing.JTextField();
        Texto4 = new javax.swing.JTextField();
        BtnAgregar = new javax.swing.JButton();
        BtnLimpiar = new javax.swing.JButton();
        BtnContinuar = new javax.swing.JButton();
        BtnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelIngresoCliente.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabelIngresoCliente.setText("INGRESO CLIENTE");

        jLabelNombre.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelNombre.setText("Nombre:");

        jLabelRut.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelRut.setText("Rut:");

        jLabelMail.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelMail.setText("Mail:");

        jLabelTelefono.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelTelefono.setText("Telefono:");

        Texto1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        Texto3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        Texto2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        Texto4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        BtnAgregar.setText("Agregar");

        BtnLimpiar.setText("Limpiar");

        BtnContinuar.setText("Continuar");

        BtnSalir.setText("Salir");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelNombre)
                                    .addComponent(jLabelRut)
                                    .addComponent(jLabelMail))
                                .addGap(21, 21, 21)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(Texto2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                                    .addComponent(Texto1, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Texto3)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelTelefono)
                                .addGap(18, 18, 18)
                                .addComponent(Texto4, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(140, 140, 140)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnAgregar)
                            .addComponent(BtnSalir)
                            .addComponent(BtnContinuar)
                            .addComponent(BtnLimpiar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jLabelIngresoCliente)))
                .addContainerGap(131, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabelIngresoCliente)
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre)
                    .addComponent(Texto1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnAgregar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnContinuar)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelRut)
                        .addComponent(Texto2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnLimpiar)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelMail)
                        .addComponent(Texto3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnSalir)
                    .addComponent(jLabelTelefono)
                    .addComponent(Texto4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(159, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAgregar;
    private javax.swing.JButton BtnContinuar;
    private javax.swing.JButton BtnLimpiar;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JTextField Texto1;
    private javax.swing.JTextField Texto2;
    private javax.swing.JTextField Texto3;
    private javax.swing.JTextField Texto4;
    private javax.swing.JLabel jLabelIngresoCliente;
    private javax.swing.JLabel jLabelMail;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelRut;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
