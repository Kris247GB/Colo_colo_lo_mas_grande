package com.mycompany.proyecto.Modelo;
 
public class Suv extends Vehiculo {
    private boolean traccion4x4;

    public Suv() {
        traccion4x4 = true;
    }

    public Suv(boolean traccion4x4) {
        this.traccion4x4 = traccion4x4;
    }

    public Suv(boolean traccion4x4, String codigo, String marca, String modelo, String patente, double precio) {
        super(codigo, marca, modelo, patente, precio);
        this.traccion4x4 = traccion4x4;
    }

    public boolean isTraccion4x4() {
        return traccion4x4;
    }

    public void setTraccion4x4(boolean traccion4x4) {
        this.traccion4x4 = traccion4x4;
    }
    
    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Traccion 4x4: " + (traccion4x4 ? "Si" : "No"));
    }
}
